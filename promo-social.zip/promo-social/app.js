(function () {
'use strict';
const $ = (id) => document.getElementById(id);
const esc = (s) => String(s == null ? '' : s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const cfg = window.PROMO_CONFIG || {};

if (!cfg.SUPABASE_URL || !cfg.SUPABASE_ANON_KEY || !window.supabase) {
  if (cfg.SUPABASE_URL && cfg.SUPABASE_ANON_KEY && !window.supabase) $('setupMsg').textContent = 'The database library could not load. Check your internet connection and refresh.';
  $('setup').hidden = false; $('view').hidden = true; $('nav').hidden = true;
  return;
}
const sb = window.supabase.createClient(cfg.SUPABASE_URL, cfg.SUPABASE_ANON_KEY);
const MEDIA_BASE = cfg.SUPABASE_URL.replace(/\/+$/, '') + '/storage/v1/object/public/media/';
const okMedia = (u) => typeof u === 'string' && u.indexOf(MEDIA_BASE) === 0 && !/['"()<>\s\\]/.test(u);
const SEL = 'id,user_id,kind,media_url,caption,created_at,profiles(username,display_name,avatar_url)';
const PAGE = 10, MAX_VIDEO = 50 * 1048576;
let me = null, myProf = null, tok = 0, feedFrom = 0, cache = {};

function toast(t) { const e = $('toast'); e.textContent = t; e.className = 'show'; clearTimeout(toast.t); toast.t = setTimeout(() => { e.className = ''; }, 3200); }
function ago(ts) {
  const s = Math.max(1, Math.floor((Date.now() - new Date(ts).getTime()) / 1000));
  if (s < 60) return 'just now'; if (s < 3600) return Math.floor(s / 60) + ' min ago'; if (s < 86400) return Math.floor(s / 3600) + ' h ago';
  if (s < 604800) return Math.floor(s / 86400) + ' d ago'; return new Date(ts).toLocaleDateString();
}
function avatar(u, size) {
  u = u || {}; const st = 'width:' + size + 'px;height:' + size + 'px;font-size:' + Math.round(size / 2.4) + 'px';
  return okMedia(u.avatar_url) ? '<img class="av" style="' + st + '" alt="" src="' + esc(u.avatar_url) + '">' : '<span class="av" style="' + st + '" aria-hidden="true">' + esc((u.username || '?').charAt(0).toUpperCase()) + '</span>';
}
function compress(file, maxSide) {
  return new Promise((ok) => {
    const u = URL.createObjectURL(file), im = new Image();
    im.onload = () => {
      const r = Math.min(1, maxSide / Math.max(im.width, im.height)), c = document.createElement('canvas');
      c.width = Math.round(im.width * r); c.height = Math.round(im.height * r);
      c.getContext('2d').drawImage(im, 0, 0, c.width, c.height); URL.revokeObjectURL(u);
      c.toBlob((b) => ok(b), 'image/jpeg', 0.86);
    };
    im.onerror = () => { URL.revokeObjectURL(u); ok(null); };
    im.src = u;
  });
}
function rid() { return Date.now() + '-' + Math.random().toString(36).slice(2, 8); }

/* ---------- header ---------- */
function paint() {
  $('auth').innerHTML = me ? '<button class="btn ghost" id="b-out">Log out</button>' : '<button class="btn ghost" id="b-in">Log in</button><button class="btn" id="b-up">Sign up</button>';
  $('n-create').hidden = !me; $('n-me').hidden = !me; $('n-me').href = myProf ? '#u/' + myProf.username : '#home';
}
$('auth').addEventListener('click', (e) => {
  if (e.target.id === 'b-in') openAuth('login'); else if (e.target.id === 'b-up') openAuth('signup');
  else if (e.target.id === 'b-out') sb.auth.signOut().then(() => toast('Logged out.'));
});

/* ---------- posts ---------- */
function postHTML(p) {
  cache[p.id] = p; const u = p.profiles || {};
  const media = okMedia(p.media_url) ? (p.kind === 'video' ? '<video controls playsinline preload="metadata" src="' + esc(p.media_url) + '"></video>' : '<img loading="lazy" alt="" src="' + esc(p.media_url) + '">') : '<p class="empty">Media unavailable</p>';
  return '<article class="post"><div class="phead"><a href="#u/' + esc(u.username) + '">' + avatar(u, 32) + '<span class="phead_name">' + esc(u.username) + '</span></a>' +
    (me && me.id === p.user_id ? '<button class="link del" data-del="' + esc(p.id) + '">Delete</button>' : '') + '</div><div class="media">' + media + '</div>' +
    (p.caption ? '<p class="cap"><b>' + esc(u.username) + '</b> ' + esc(p.caption) + '</p>' : '') + '<time>' + esc(ago(p.created_at)) + '</time></article>';
}
async function del(id) {
  const p = cache[id]; if (!p || !confirm('Delete this post? This cannot be undone.')) return;
  const r = await sb.from('posts').delete().eq('id', id);
  if (r.error) { toast('Could not delete: ' + r.error.message); return; }
  if (okMedia(p.media_url)) sb.storage.from('media').remove([p.media_url.slice(MEDIA_BASE.length)]);
  if ($('dView').open) $('dView').close();
  toast('Post deleted.'); route();
}
document.addEventListener('click', (e) => {
  const d = e.target.closest && e.target.closest('[data-del]'); if (d) { del(d.dataset.del); return; }
  const t = e.target.closest && e.target.closest('[data-view]'); if (t && cache[t.dataset.view]) { $('vBody').innerHTML = postHTML(cache[t.dataset.view]); $('dView').showModal(); }
});
$('vClose').onclick = () => $('dView').close();
$('dView').addEventListener('close', () => { $('vBody').innerHTML = ''; });

/* ---------- pages ---------- */
function route() {
  const h = location.hash.replace(/^#/, ''), m = h.match(/^u\/([a-z0-9_.]{3,20})$/);
  $('n-home').setAttribute('aria-current', m ? 'false' : 'page');
  window.scrollTo(0, 0);
  if (m) showProfile(m[1]); else showHome();
}
async function showHome() {
  const t = ++tok; feedFrom = 0;
  $('view').innerHTML = '<div class="feed" id="feed"></div><div class="more"><button class="btn ghost" id="more" hidden>Load more</button></div><p class="muted center" id="fmsg">Loading…</p>';
  await loadFeed(t);
}
async function loadFeed(t) {
  const r = await sb.from('posts').select(SEL).order('created_at', { ascending: false }).range(feedFrom, feedFrom + PAGE - 1);
  if (t !== tok) return;
  if (r.error) { $('fmsg').textContent = 'Could not load posts. Run setup.sql in Supabase, then refresh. (' + r.error.message + ')'; return; }
  const rows = r.data || [];
  $('feed').insertAdjacentHTML('beforeend', rows.map(postHTML).join(''));
  feedFrom += rows.length;
  $('more').hidden = rows.length < PAGE;
  $('fmsg').textContent = feedFrom ? '' : 'No posts yet. ' + (me ? 'Tap ＋ Post to share the first one.' : 'Sign up to share the first one.');
}
$('view').addEventListener('click', (e) => { if (e.target.id === 'more') { loadFeed(tok); } if (e.target.id === 'editBtn') openEdit(); });

async function showProfile(name) {
  const t = ++tok; $('view').innerHTML = '<p class="muted center pad">Loading…</p>';
  const pr = await sb.from('profiles').select('*').eq('username', name).maybeSingle();
  if (t !== tok) return;
  if (pr.error || !pr.data) { $('view').innerHTML = '<p class="empty">Profile not found.</p>'; return; }
  const p = pr.data;
  const [cnt, posts] = await Promise.all([
    sb.from('posts').select('id', { count: 'exact', head: true }).eq('user_id', p.id),
    sb.from('posts').select(SEL).eq('user_id', p.id).order('created_at', { ascending: false }).limit(60)
  ]);
  if (t !== tok) return;
  const rows = posts.data || [];
  rows.forEach((x) => { cache[x.id] = x; });
  const tiles = rows.map((x) => '<button class="tile" data-view="' + esc(x.id) + '" aria-label="Open post">' + (okMedia(x.media_url) ? (x.kind === 'video' ? '<video muted preload="metadata" src="' + esc(x.media_url) + '#t=0.1"></video><span class="badge">▶ Video</span>' : '<img loading="lazy" alt="" src="' + esc(x.media_url) + '">') : '') + '</button>').join('');
  $('view').innerHTML = '<section class="profile">' + avatar(p, 120) + '<div class="info"><h1>' + esc(p.username) + (me && me.id === p.id ? '<button class="btn ghost" id="editBtn">Edit profile</button>' : '') + '</h1>' +
    '<div class="stats"><b>' + (cnt.count || 0) + '</b> posts</div>' + (p.display_name ? '<div class="name">' + esc(p.display_name) + '</div>' : '') + (p.bio ? '<p class="bio">' + esc(p.bio) + '</p>' : (me && me.id === p.id ? '<p class="bio muted">Add a bio to tell people about yourself.</p>' : '')) + '</div></section>' +
    (rows.length ? '<div class="grid">' + tiles + '</div>' : '<p class="empty">No posts yet.</p>');
}
window.addEventListener('hashchange', route);

/* ---------- auth ---------- */
let aMode = 'login';
function setMode(m) {
  aMode = m; $('tLogin').setAttribute('aria-pressed', String(m === 'login')); $('tSignup').setAttribute('aria-pressed', String(m === 'signup'));
  $('signupOnly').hidden = m !== 'signup'; $('aTitle').textContent = m === 'login' ? 'Log in' : 'Create your profile'; $('a-go').textContent = m === 'login' ? 'Log in' : 'Sign up';
  $('a-pass').autocomplete = m === 'login' ? 'current-password' : 'new-password'; $('a-err').textContent = ''; $('a-err').style.color = '';
}
function openAuth(m) { setMode(m); $('dAuth').showModal(); }
$('tLogin').onclick = () => setMode('login'); $('tSignup').onclick = () => setMode('signup'); $('a-cancel').onclick = () => $('dAuth').close();
$('a-go').onclick = async () => {
  const email = $('a-email').value.trim(), pass = $('a-pass').value, err = $('a-err'); err.textContent = ''; err.style.color = '';
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) { err.textContent = 'Enter a valid email.'; return; }
  if (pass.length < 8) { err.textContent = 'Password must be at least 8 characters.'; return; }
  $('a-go').disabled = true;
  try {
    if (aMode === 'login') {
      const r = await sb.auth.signInWithPassword({ email: email, password: pass });
      if (r.error) { err.textContent = r.error.message; return; }
      $('dAuth').close(); toast('Welcome back.');
    } else {
      const uname = $('a-user').value.trim().toLowerCase(), dn = $('a-name').value.trim();
      if (!/^[a-z0-9_.]{3,20}$/.test(uname)) { err.textContent = 'Username: 3 to 20 letters, numbers, dots or underscores.'; return; }
      const ex = await sb.from('profiles').select('id').eq('username', uname).maybeSingle();
      if (ex.data) { err.textContent = 'That username is taken. Try another.'; return; }
      const r = await sb.auth.signUp({ email: email, password: pass, options: { data: { username: uname, display_name: dn } } });
      if (r.error) { err.textContent = r.error.message; return; }
      if (!r.data.session) { err.textContent = ''; $('aTitle').textContent = 'Check your email'; $('a-err').style.color = '#111'; $('a-err').textContent = 'We sent a confirmation link to ' + email + '. Open it, then log in.'; return; }
      $('dAuth').close(); toast('Your profile is ready. Add a bio!');
    }
  } finally { $('a-go').disabled = false; }
};

/* ---------- new post / video ---------- */
let cKind = 'photo', cFile = null, cPrev = '';
function setKind(k) {
  cKind = k; cFile = null; $('c-file').value = ''; $('c-prev').innerHTML = ''; $('c-err').textContent = '';
  $('kPhoto').setAttribute('aria-pressed', String(k === 'photo')); $('kVideo').setAttribute('aria-pressed', String(k === 'video'));
  $('c-file').accept = k === 'photo' ? 'image/*' : 'video/mp4,video/webm,video/quicktime'; $('c-label').textContent = k === 'photo' ? 'Choose a photo' : 'Choose a video (max 50 MB)';
}
function openCreate() { if (!me) { openAuth('login'); return; } if (!myProf) { toast('Your profile is not ready. Run setup.sql in Supabase.'); return; } setKind('photo'); $('c-cap').value = ''; $('dCreate').showModal(); }
$('n-create').onclick = openCreate; $('kPhoto').onclick = () => setKind('photo'); $('kVideo').onclick = () => setKind('video'); $('c-cancel').onclick = () => $('dCreate').close();
$('c-file').addEventListener('change', function () {
  const f = this.files && this.files[0]; cFile = null; $('c-prev').innerHTML = ''; $('c-err').textContent = ''; if (!f) return;
  if (cKind === 'photo' && f.type.indexOf('image/') !== 0) { $('c-err').textContent = 'Please choose an image.'; return; }
  if (cKind === 'video' && !/^video\/(mp4|webm|quicktime)$/.test(f.type)) { $('c-err').textContent = 'Please choose an MP4, WebM or MOV video.'; return; }
  if (cKind === 'video' && f.size > MAX_VIDEO) { $('c-err').textContent = 'That video is over 50 MB. Choose a shorter one.'; return; }
  if (cKind === 'photo' && f.size > 25 * 1048576) { $('c-err').textContent = 'That photo is over 25 MB.'; return; }
  cFile = f; if (cPrev) URL.revokeObjectURL(cPrev); cPrev = URL.createObjectURL(f);
  $('c-prev').innerHTML = cKind === 'photo' ? '<img alt="" src="' + cPrev + '">' : '<video controls playsinline muted src="' + cPrev + '"></video>';
});
$('c-go').onclick = async () => {
  const err = $('c-err'); err.textContent = '';
  if (!me || !myProf) { err.textContent = 'Please log in first.'; return; }
  if (!cFile) { err.textContent = cKind === 'photo' ? 'Choose a photo first.' : 'Choose a video first.'; return; }
  $('c-go').disabled = true; $('c-go').textContent = 'Uploading…'; let path = '';
  try {
    let blob = cFile, ctype = cFile.type, ext;
    if (cKind === 'photo') { blob = await compress(cFile, 1440); if (!blob) { err.textContent = 'Could not read that photo. Try a JPG or PNG.'; return; } ctype = 'image/jpeg'; ext = 'jpg'; }
    else ext = ctype === 'video/webm' ? 'webm' : (ctype === 'video/quicktime' ? 'mov' : 'mp4');
    path = me.id + '/' + rid() + '.' + ext;
    const up = await sb.storage.from('media').upload(path, blob, { contentType: ctype, cacheControl: '3600' });
    if (up.error) { err.textContent = 'Upload failed: ' + up.error.message; path = ''; return; }
    const url = sb.storage.from('media').getPublicUrl(path).data.publicUrl;
    const ins = await sb.from('posts').insert({ user_id: me.id, kind: cKind, media_url: url, caption: $('c-cap').value.trim().slice(0, 2200) });
    if (ins.error) { sb.storage.from('media').remove([path]); err.textContent = 'Could not save your post: ' + ins.error.message; path = ''; return; }
    path = ''; $('dCreate').close(); toast(cKind === 'video' ? 'Video shared.' : 'Post shared.');
    if (location.hash === '#home' || location.hash === '') route(); else location.hash = 'home';
  } finally { $('c-go').disabled = false; $('c-go').textContent = 'Share'; }
};

/* ---------- edit profile / bio ---------- */
let eAvatar = null;
function openEdit() {
  if (!myProf) return; eAvatar = null; $('e-err').textContent = ''; $('e-name').value = myProf.display_name || ''; $('e-bio').value = myProf.bio || ''; $('e-count').textContent = $('e-bio').value.length;
  $('e-av').innerHTML = avatar(myProf, 72); $('dEdit').showModal();
}
$('e-bio').addEventListener('input', () => { $('e-count').textContent = $('e-bio').value.length; });
$('e-cancel').onclick = () => $('dEdit').close();
$('e-file').addEventListener('change', async function () {
  const f = this.files && this.files[0]; if (!f) return;
  const b = await compress(f, 480); if (!b) { $('e-err').textContent = 'Could not read that photo.'; return; }
  eAvatar = b; $('e-av').innerHTML = '<img class="av" style="width:72px;height:72px" alt="" src="' + URL.createObjectURL(b) + '">';
});
$('e-go').onclick = async () => {
  $('e-go').disabled = true; $('e-err').textContent = '';
  try {
    let url = myProf.avatar_url || null;
    if (eAvatar) {
      const path = me.id + '/avatar-' + rid() + '.jpg', up = await sb.storage.from('media').upload(path, eAvatar, { contentType: 'image/jpeg', cacheControl: '3600' });
      if (up.error) { $('e-err').textContent = 'Photo upload failed: ' + up.error.message; return; }
      if (okMedia(url)) sb.storage.from('media').remove([url.slice(MEDIA_BASE.length)]);
      url = sb.storage.from('media').getPublicUrl(path).data.publicUrl;
    }
    const r = await sb.from('profiles').update({ display_name: $('e-name').value.trim().slice(0, 50) || null, bio: $('e-bio').value.trim().slice(0, 150) || null, avatar_url: url }).eq('id', me.id);
    if (r.error) { $('e-err').textContent = 'Could not save: ' + r.error.message; return; }
    await loadMyProf(); $('dEdit').close(); toast('Profile updated.'); route();
  } finally { $('e-go').disabled = false; }
};

/* ---------- session ---------- */
async function loadMyProf() { if (!me) { myProf = null; return; } const r = await sb.from('profiles').select('*').eq('id', me.id).maybeSingle(); myProf = r.data || null; }
async function apply(session) { me = session ? session.user : null; await loadMyProf(); paint(); route(); }
(async function boot() {
  const s = await sb.auth.getSession(); await apply(s.data && s.data.session);
  sb.auth.onAuthStateChange((evt, session) => { if (evt === 'SIGNED_IN' || evt === 'SIGNED_OUT' || evt === 'USER_UPDATED') setTimeout(() => apply(session), 0); });
})();
})();

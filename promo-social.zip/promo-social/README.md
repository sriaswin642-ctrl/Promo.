# Promo - classic black and white, Instagram-style

What it does (only these):
- Create a profile (sign up with email and password, choose a username)
- Add a bio, a name and a profile photo
- Add a photo post with a caption
- Add a video post with a caption
- See everyone's posts on Home, and each person's posts on their profile grid
- Delete your own posts

Files: index.html, styles.css, app.js, config.js, logo.png, setup.sql

## Part 1 - Create the database (Supabase, free plan, about 10 minutes)
1. Go to supabase.com, sign in, and tap New project. Choose a name, a database password (save it), and the region closest to you.
2. When the project is ready, open SQL Editor > New query. Open setup.sql from this folder, copy ALL of it, paste it, and tap Run. It should say "Success".
   This creates the profiles table, the posts table, the security rules, the automatic profile creation, and a storage bucket called media for photos and videos.
3. Authentication > Sign In / Providers > Email. For easiest testing, turn OFF "Confirm email" (people can then sign up and post immediately). Leave it ON if you want people to confirm their email first.
4. Authentication > URL Configuration: set Site URL to your live website address (after step 6).
5. Project Settings > API: copy the Project URL and the "anon public" key.
6. Open config.js and paste the two values between the quotes. NEVER paste the "service_role" key anywhere in the site.

## Part 2 - Put the website online
1. On a computer, go to app.netlify.com/drop and drag this whole folder onto the page.
   (GitHub + Vercel also works: upload all the files.)
2. Open your link. Sign up, add a bio, and post a photo and a video to test it.

## Notes
- The anon key is public by design. The security rules in setup.sql decide who can read, add or delete what: everyone can read; only the owner can edit their profile or delete their posts and files.
- Videos: MP4, WebM or MOV up to 50 MB (the limit set in setup.sql; the free plan may enforce its own limit, so check Supabase's current limits).
- Free Supabase projects have storage and bandwidth limits, and may pause after a period of inactivity. Check Supabase's current plan details.
- To remove a user or a post yourself, open Supabase > Table Editor (and Storage for the files).
- Login by mobile number (OTP) needs an SMS provider and is not included. Login is by email and password.
- There are no comments, likes or messages, as requested.

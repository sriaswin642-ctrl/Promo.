// Paste your two Supabase values here (Supabase > Project Settings > API).
// The "anon public" key is meant to be public. NEVER paste the "service_role" key.
window.PROMO_CONFIG = {
  SUPABASE_URL: '',       // e.g. https://abcdxyz.supabase.co
  SUPABASE_ANON_KEY: ''   // the long "anon public" key
};
